# Sound Feedback – Unfinished Project (UP)

**Topic:** Sound, music – *Sound feedback when posting or selling a listing*
**Authors:** Pedro Silva & André Cordeiro

## The app
**Sound Market** is a small marketplace made with Kotlin + Jetpack Compose.
You can **post** a listing (button "+ Post listing") and **mark a listing as sold**.

The app already works, but it is **silent**. Your job is to add **sound feedback**:

| Action          | Sound                  |
|-----------------|------------------------|
| Listing posted  | `res/raw/sound_post.wav` |
| Listing sold    | `res/raw/sound_sold.wav` |

## How to run
1. Clone this repository (or download the ZIP) and open the folder in **Android Studio**.
2. Wait for the Gradle sync to finish.
3. Run the app on an emulator or phone (▶). Turn the volume up!

## Exercise
The parts of the code that play sounds were removed. Complete them in this order:

### 1. `SoundManager.kt`
1. **`soundPool`** – build it with `SoundPool.Builder()`: `setMaxStreams(3)` and
   `setAudioAttributes(...)` with `USAGE_ASSISTANCE_SONIFICATION` and `CONTENT_TYPE_SONIFICATION`.
2. **`init`** – register `soundPool.setOnLoadCompleteListener { _, sampleId, status -> ... }`
   and add `sampleId` to `loadedSounds` when `status == 0`.
3. **`init`** – load the sounds: `postSoundId = soundPool.load(context, R.raw.sound_post, 1)`
   and the same for `R.raw.sound_sold` → `soldSoundId`.
4. **`play()`** – return if `isEnabled` is false or the sound is not in `loadedSounds`.
5. **`play()`** – call `soundPool.play(soundId, 1f, 1f, 1, 0, 1f)`.
6. **`release()`** – call `soundPool.release()` and clear `loadedSounds`.

### 2. `ui/MarketScreen.kt`
7. In `onPost` (after `viewModel.postListing(...)`) → play the **post** sound.
8. In `onMarkSold` (inside the `if`) → play the **sold** sound.
   Bonus: `haptic.performHapticFeedback(HapticFeedbackType.LongPress)`.

### 3. `MainActivity.kt`
9. In `onDestroy()` → call `soundManager.release()`.

## How to check your solution
- Post a listing → you hear a short sound.
- Mark a listing as sold → you hear the "sold" sound (and feel a vibration on a real phone).
- Turn the switch in the top bar off → no sound at all.

## Bonus challenges
1. Add a **volume slider** and use it in `soundPool.play(...)`.
2. Add an **error sound** when the user tries to post an empty listing.
3. Don't play sounds when the phone is in **silent mode**
   (`AudioManager.ringerMode != AudioManager.RINGER_MODE_NORMAL`).

## Useful docs
- SoundPool: https://developer.android.com/reference/android/media/SoundPool
- AudioAttributes: https://developer.android.com/reference/android/media/AudioAttributes
