package com.example.soundfeedback

data class Listing(
    val id: Int,
    val title: String,
    val price: Double,
    val isSold: Boolean = false
)
