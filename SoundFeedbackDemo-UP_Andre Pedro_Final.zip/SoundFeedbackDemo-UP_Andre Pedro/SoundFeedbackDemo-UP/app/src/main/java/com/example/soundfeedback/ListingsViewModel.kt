package com.example.soundfeedback

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

class ListingsViewModel : ViewModel() {
    private var nextId = 4

    val listings = mutableStateListOf(
        Listing(1, "Old bicycle", 80.0),
        Listing(2, "Kotlin book", 25.0),
        Listing(3, "Desk lamp", 15.0, isSold = true)
    )

    fun postListing(title: String, price: Double) {
        listings.add(0, Listing(nextId++, title.trim(), price))
    }

    fun markAsSold(id: Int): Boolean {
        val index = listings.indexOfFirst { it.id == id }
        if (index == -1 || listings[index].isSold) return false
        listings[index] = listings[index].copy(isSold = true)
        return true
    }
}
