package com.example.soundfeedback

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.example.soundfeedback.ui.MarketScreen

class MainActivity : ComponentActivity() {
    private lateinit var soundManager: SoundManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        soundManager = SoundManager(this)

        setContent {
            MaterialTheme {
                MarketScreen(soundManager = soundManager)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
