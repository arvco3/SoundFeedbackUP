package com.example.soundfeedback

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

class SoundManager(context: Context) {
    private val soundPool: SoundPool = SoundPool.Builder().build()

    private val loadedSounds = mutableSetOf<Int>()

    private val postSoundId: Int
    private val soldSoundId: Int

    var isEnabled: Boolean = true

    init {
        postSoundId = 0
        soldSoundId = 0
    }

    fun playPost() = play(postSoundId)

    fun playSold() = play(soldSoundId)

    private fun play(soundId: Int) {
    }

    fun release() {
    }
}
