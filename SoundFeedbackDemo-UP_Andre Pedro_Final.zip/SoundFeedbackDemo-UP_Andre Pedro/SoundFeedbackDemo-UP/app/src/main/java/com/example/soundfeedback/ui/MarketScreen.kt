package com.example.soundfeedback.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.soundfeedback.Listing
import com.example.soundfeedback.ListingsViewModel
import com.example.soundfeedback.SoundManager
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketScreen(
    soundManager: SoundManager,
    viewModel: ListingsViewModel = viewModel()
) {
    val haptic = LocalHapticFeedback.current
    var soundOn by remember { mutableStateOf(soundManager.isEnabled) }
    var showPostDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sound Market") },
                actions = {
                    Text(if (soundOn) "Sound on" else "Muted")
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = soundOn,
                        onCheckedChange = {
                            soundOn = it
                            soundManager.isEnabled = it
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showPostDialog = true }) {
                Text("+ Post listing")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(viewModel.listings, key = { it.id }) { listing ->
                ListingCard(
                    listing = listing,
                    onMarkSold = {
                        if (viewModel.markAsSold(listing.id)) {
                        }
                    }
                )
            }
        }
    }

    if (showPostDialog) {
        PostListingDialog(
            onDismiss = { showPostDialog = false },
            onPost = { title, price ->
                viewModel.postListing(title, price)
                showPostDialog = false
            }
        )
    }
}

@Composable
fun ListingCard(listing: Listing, onMarkSold: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(listing.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    String.format(Locale.US, "%.2f €", listing.price),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (listing.isSold) {
                Text("SOLD", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
            } else {
                Button(onClick = onMarkSold) { Text("Mark as sold") }
            }
        }
    }
}

@Composable
fun PostListingDialog(onDismiss: () -> Unit, onPost: (String, Double) -> Unit) {
    var title by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    val price = priceText.replace(',', '.').toDoubleOrNull()
    val isValid = title.isNotBlank() && price != null && price >= 0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New listing") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Price (€)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (price != null) onPost(title, price) },
                enabled = isValid
            ) { Text("Post") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
